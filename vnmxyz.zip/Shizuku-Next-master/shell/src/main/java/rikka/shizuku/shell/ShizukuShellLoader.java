package rikka.shizuku.shell;

import android.app.ActivityManagerNative;
import android.app.IActivityManager;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.system.Os;
import android.text.TextUtils;

import java.io.File;
import java.util.Objects;

import dalvik.system.BaseDexClassLoader;
import rikka.hidden.compat.PackageManagerApis;
import stub.dalvik.system.VMRuntimeHidden;

public class ShizukuShellLoader {

    private static String[] args;
    private static String callingPackage;
    private static Handler handler;

    /**
     * Whether a binder has been handed over already. Only ever read and written on the main
     * looper, which is where the receiver binder and the fallback below both run, so it needs no
     * more than this.
     */
    private static boolean answered;

    private static final Binder receiverBinder = new Binder() {

        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            if (code == 1) {
                IBinder binder = data.readStrongBinder();

                String sourceDir = data.readString();
                if (binder != null) {
                    handler.post(() -> onBinderReceived(binder, sourceDir));
                } else {
                    System.err.println("Server is not running");
                    System.err.flush();
                    System.exit(1);
                }
                return true;
            }
            return super.onTransact(code, data, reply, flags);
        }
    };

    private static void requestForBinder() throws Exception {
        Bundle data = new Bundle();
        data.putBinder("binder", receiverBinder);

        final String managerApplicationId = managerApplicationId();

        Intent intent = new Intent("rikka.shizuku.intent.action.REQUEST_BINDER")
                .setPackage(managerApplicationId)
                .addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                .putExtra("data", data);

        IBinder amBinder = ServiceManager.getService("activity");
        IActivityManager am;
        if (Build.VERSION.SDK_INT >= 26) {
            am = IActivityManager.Stub.asInterface(amBinder);
        } else {
            am = ActivityManagerNative.asInterface(amBinder);
        }

        // broadcastIntent will fail on Android 8.x
        //  com.android.server.am.ActivityManagerService.isInstantApp(ActivityManagerService.java:18547)
        //  com.android.server.am.ActivityManagerService.broadcastIntentLocked(ActivityManagerService.java:18972)
        //  com.android.server.am.ActivityManagerService.broadcastIntent(ActivityManagerService.java:19703)
        //
        try {
            am.broadcastIntent(null, intent, null, null, 0, null, null,
                    null, -1, null, true, false, 0);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.BAKLAVA) {
                // Android 16 does not deliver a broadcast sent from app_process to a receiver in
                // another app on every OEM: on some the call above reports success and onReceive
                // is never called, which leaves this sitting here until the timeout. The manager's
                // activity answers the same exchange - ShellRequestHandlerActivity runs the very
                // ShellBinderRequestHandler the receiver does - so the request is made that way
                // too, unless the broadcast was answered first. Where the broadcast does arrive,
                // as it did on every device this was tried on, nothing is started and nothing
                // changes; only a device that drops it sees the second request.
                handler.postDelayed(() -> {
                    if (answered) {
                        return;
                    }

                    try {
                        Intent activityIntent = new Intent("rikka.shizuku.intent.action.REQUEST_BINDER")
                                .setPackage(managerApplicationId)
                                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                .putExtra("data", data);

                        am.startActivityAsUser(null, callingPackage, activityIntent, null, null, null,
                                0, 0, null, null, Os.getuid() / 100000);
                    } catch (Throwable t) {
                        t.printStackTrace(System.err);
                        System.err.flush();
                    }
                }, 1000);
            }
        } catch (Throwable e) {
            if ((Build.VERSION.SDK_INT != Build.VERSION_CODES.O && Build.VERSION.SDK_INT != Build.VERSION_CODES.O_MR1)
                    || !Objects.equals(e.getMessage(), "Calling application did not provide package name")) {
                throw e;
            }

            System.err.println("broadcastIntent fails on Android 8.0 or 8.1, fallback to startActivity");
            System.err.flush();

            Intent activityIntent = Intent.createChooser(
                    new Intent("rikka.shizuku.intent.action.REQUEST_BINDER")
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
                            .putExtra("data", data),
                    "Request binder from Shizuku"
            );

            am.startActivityAsUser(null, callingPackage, activityIntent, null, null, null, 0, 0, null, null, Os.getuid() / 100000);
        }
    }

    /**
     * The application id of the manager to ask, from the environment when rish set it there and
     * from this build otherwise.
     */
    private static String managerApplicationId() {
        String fromEnvironment = System.getenv("MANAGER_APPLICATION_ID");
        if (TextUtils.isEmpty(fromEnvironment) || "MANAGER_PKG".equals(fromEnvironment)) {
            return BuildConfig.MANAGER_APPLICATION_ID;
        }
        return fromEnvironment;
    }

    private static void onBinderReceived(IBinder binder, String sourceDir) {
        // The broadcast and the fallback can both be delivered when the first one is merely slow:
        // the first to arrive is the one that counts, or the shell would be started twice.
        if (answered) {
            return;
        }
        answered = true;

        var base = sourceDir.substring(0, sourceDir.lastIndexOf('/'));
        String librarySearchPath = base + "/lib/" + VMRuntimeHidden.getRuntime().vmInstructionSet();
        String systemLibrarySearchPath = System.getProperty("java.library.path");
        if (!TextUtils.isEmpty(systemLibrarySearchPath)) {
            librarySearchPath += File.pathSeparatorChar + systemLibrarySearchPath;
        }

        try {
            System.out.println("Entering shell...");
            var classLoader = new BaseDexClassLoader(sourceDir, null, librarySearchPath, ClassLoader.getSystemClassLoader());
            Class<?> cls = classLoader.loadClass("moe.shizuku.manager.shell.Shell");
            cls.getDeclaredMethod("main", String[].class, String.class, IBinder.class, Handler.class)
                    .invoke(null, args, callingPackage, binder, handler);
        } catch (ClassNotFoundException tr) {
            System.err.println("Class not found");
            System.err.println("Make sure you have Shizuku v12.0.0 or above installed");
            System.err.flush();
            System.exit(1);
        } catch (Throwable tr) {
            tr.printStackTrace(System.err);
            System.err.flush();
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        ShizukuShellLoader.args = args;

        String packageName;
        var pkg = PackageManagerApis.getPackagesForUidNoThrow(Os.getuid());
        if (pkg.size() == 1) {
            packageName = pkg.get(0);
        } else {
            packageName = System.getenv("RISH_APPLICATION_ID");
            if (TextUtils.isEmpty(packageName) || "PKG".equals(packageName)) {
                abort("RISH_APPLICATION_ID is not set, please set this environment variable in rish to the package name of the terminal app");
                System.exit(1);
            }
        }

        ShizukuShellLoader.callingPackage = packageName;

        if (Looper.getMainLooper() == null) {
            Looper.prepareMainLooper();
        }

        handler = new Handler(Looper.getMainLooper());

        try {
            requestForBinder();
        } catch (Throwable tr) {
            tr.printStackTrace(System.err);
            System.err.flush();
            System.exit(1);
        }

        handler.postDelayed(() -> abort(
                String.format(
                        "Request timeout. " +
                        "If you are using stealth mode, MANAGER_APPLICATION_ID may not be correct. Please set this environment variable in rish to the package name of Shizuku.\n" +
                        "Otherwise, the connection between the current app (%1$s) and Shizuku app may be blocked by your system. " +
                        "Please disable all battery optimization features for both current app (%1$s) and Shizuku app.",
                        packageName)
        ), 5000);

        Looper.loop();
        System.exit(0);
    }

    private static void abort(String message) {
        System.err.println(message);
        System.err.flush();
        System.exit(1);
    }
}
