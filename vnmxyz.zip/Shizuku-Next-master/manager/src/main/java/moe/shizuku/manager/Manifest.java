package moe.shizuku.manager;

public class Manifest {

    public static class permission_group {
        public static final String API = "moe.shizuku.manager.permission-group.API";
    }

    public static class permission {
        public static final String API_V23 = "moe.shizuku.manager.permission.API_V23";
    }
}
