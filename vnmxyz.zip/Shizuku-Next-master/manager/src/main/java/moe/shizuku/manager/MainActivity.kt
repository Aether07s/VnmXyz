package moe.shizuku.manager

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import moe.shizuku.manager.adb.AdbPairingService
import moe.shizuku.manager.home.showAccessibilityDialog
import moe.shizuku.manager.receiver.ShizukuReceiverStarter
import moe.shizuku.manager.ui.ShizukuApp
import moe.shizuku.manager.ui.screen.SetupScreen
import moe.shizuku.manager.ui.theme.ShizukuTheme
import moe.shizuku.manager.utils.AppLocale
import moe.shizuku.manager.utils.Diag
import moe.shizuku.manager.utils.EnvironmentUtils

class MainActivity : FragmentActivity() {

    /**
     * Starting Shizuku is announced in a notification, which also carries the buttons to
     * retry or cancel the attempt but on Android 13+ the app has to ask for the
     * notification permission at runtime, or none of it is ever shown.
     */
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED
        ) return

        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    /**
     * The whole Compose UI lives here, and unlike the activities that come from `MaterialActivity`
     * this one used to attach with the device's language whatever the user had chosen. On
     * Android 13+ the per-app locale is already in the configuration and [AppLocale.wrap] leaves
     * it alone; below that this is what makes the choice take effect.
     */
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLocale.wrap(newBase))
    }

    /**
     * The chosen language is not only chosen here: from Android 13 the system settings screen
     * changes the per-app locale too, and the framework only rebuilds the activities when it
     * does - the process, and with it the stored copy of the choice, survives. Reconciling on
     * the way back to the foreground is what keeps the picker and the row from reporting a
     * language that is no longer in force.
     */
    override fun onResume() {
        super.onResume()
        AppLocale.reconcile(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)

        // A fresh install meets the guided setup instead of the notification dialog, because
        // that dialog is where the setup explains it: asked from here it arrived before anything
        // had been drawn, with nothing to say why. Installs that already knew the app, and a TV
        // with no keyboard-free way through a wizard, keep the dialog and go straight in.
        val showSetup = !ShizukuSettings.isSetupDone(this) && !EnvironmentUtils.isTelevision()
        if (!showSetup) {
            requestNotificationPermission()
        }

        setContent {
            var setup by rememberSaveable { mutableStateOf(showSetup) }
            if (setup) {
                ShizukuTheme {
                    SetupScreen(
                        onFinish = {
                            // Skipping writes the same thing as finishing: the setup is not
                            // asked again, and whatever was left undone is still on the home
                            // screen, where it was before.
                            ShizukuSettings.setSetupDone()
                            setup = false
                        }
                    )
                }
            } else {
                ShizukuApp(onRunSetup = { setup = true })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /**
     * Handles the extras that start Shizuku or ask for the pairing dialog, including the request
     * sent by the accessibility service when it connects.
     */
    private fun handleIntent(intent: Intent?) {
        if (intent == null) return

        if (intent.getBooleanExtra(AppConstants.EXTRA_START_SERVICE_VIA_WADB, false)) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .cancel(AdbPairingService.NOTIFICATION_ID)
            ShizukuReceiverStarter.start(this, forceStart = true, userInitiated = true, reason = "wadb-intent")
        }

        if (intent.getBooleanExtra(AppConstants.EXTRA_SHOW_PAIRING_DIALOG, false)) {
            // Asked for by the pairing accessibility service as it connects. A throw here would
            // take the whole process down with it, service included, and Android then switches
            // the service back off - which is how it looked on TV. The home screen guards the
            // same call the same way.
            runCatching { showAccessibilityDialog() }
                .onFailure { Diag.warn(AppConstants.TAG, "Could not show the pairing dialog", it) }
        }
    }
}
